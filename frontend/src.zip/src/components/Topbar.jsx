import React, { useState } from "react";

const ANOMALY_OPTIONS = [
  { value: "temperature_spike", label: "🌡️ Temp Spike" },
  { value: "humidity_spike", label: "💧 Humidity Saturation" },
  { value: "pressure_jump", label: "◉ Pressure Drop" },
  { value: "freeze", label: "❄️ Frozen Sensor" },
  { value: "drift", label: "📈 Sensor Drift" },
  { value: "offset", label: "⚖️ Offset Step" },
  { value: "multivariate_inconsistency", label: "⚡ Physics Conflict" },
  { value: "spatial_inconsistency", label: "📍 Spatial Outlier" }
];

function Topbar({ simulatorRunning = true, onToggleSimulator, onTriggerCycle, wsConnected = true }) {
  const [selectedAnomaly, setSelectedAnomaly] = useState("temperature_spike");
  const [injecting, setInjecting] = useState(false);

  const handleInject = async () => {
    setInjecting(true);
    if (onTriggerCycle) {
      await onTriggerCycle(selectedAnomaly);
    }
    setTimeout(() => setInjecting(false), 600);
  };

  return (
    <header className="topbar">
      <div style={{ display: "flex", alignItems: "center", gap: "16px", flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <span className="live-dot" style={{ background: wsConnected ? "#35df9a" : "#ef3d59", boxShadow: wsConnected ? "0 0 12px #35df9a" : "0 0 12px #ef3d59" }}></span>
          <span style={{ fontSize: "11px", fontWeight: "700", letterSpacing: "0.5px" }}>{wsConnected ? "LIVE TELEMETRY" : "CONNECTING..."}</span>
        </div>

        <div className="sim-controls">
          <div className="sim-status-pill">
            <span className={simulatorRunning ? "dot-active" : "dot-paused"}></span>
            <span>{simulatorRunning ? "STREAM: 5s" : "STREAM: PAUSED"}</span>
          </div>

          <button
            className={`sim-btn ${simulatorRunning ? "sim-btn-stop" : "sim-btn-start"}`}
            onClick={onToggleSimulator}
            title={simulatorRunning ? "Pause incoming telemetry simulation" : "Start telemetry stream every 5s"}
          >
            {simulatorRunning ? "⏸ Pause Stream" : "▶ Resume (5s)"}
          </button>
        </div>

        {/* ANOMALY INJECTOR TOOLBAR */}
        <div style={{ display: "flex", alignItems: "center", gap: "6px", background: "rgba(255,255,255,0.03)", padding: "4px 8px", borderRadius: "8px", border: "1px solid rgba(255,255,255,0.06)" }}>
          <select
            value={selectedAnomaly}
            onChange={(e) => setSelectedAnomaly(e.target.value)}
            style={{
              background: "#0b0f19",
              border: "1px solid rgba(255,255,255,0.1)",
              color: "#f5f7ff",
              padding: "4px 8px",
              borderRadius: "6px",
              fontSize: "11px",
              cursor: "pointer"
            }}
          >
            {ANOMALY_OPTIONS.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>

          <button
            className="sim-btn sim-btn-trigger"
            style={{ padding: "4px 10px", fontSize: "11px" }}
            onClick={handleInject}
            disabled={injecting}
            title="Inject selected anomaly into telemetry stream"
          >
            {injecting ? "⚡ Injecting..." : "⚡ Inject"}
          </button>
        </div>
      </div>

      <div className="topbar-right" style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <div style={{ textAlign: "right" }}>
          <strong style={{ fontSize: "12px", color: "#f5f7ff", display: "block" }}>Ankita M.</strong>
          <span style={{ fontSize: "10px", color: "#35df9a" }}>● System Administrator</span>
        </div>
        <div className="top-avatar" style={{ background: "linear-gradient(135deg, #6877ff, #35df9a)", color: "#fff", fontWeight: "bold" }}>A</div>
      </div>
    </header>
  );
}

export default Topbar;
