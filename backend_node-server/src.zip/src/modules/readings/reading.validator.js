import { z } from "zod";

export const sensorReadingSchema = z.object({
    stationId: z.string().optional(),
    station_id: z.string().optional(),
    stationName: z.string().optional(),
    station_name: z.string().optional(),
    city: z.string().optional(),
    cluster: z.string().optional(),
    latitude: z.coerce.number().optional(),
    longitude: z.coerce.number().optional(),
    timestamp: z.union([z.string(), z.coerce.date()]).optional(),
    temperature: z.coerce.number().optional(),
    temperature_c: z.coerce.number().optional(),
    humidity: z.coerce.number().optional(),
    humidity_pct: z.coerce.number().optional(),
    pressure: z.coerce.number().optional(),
    pressure_hpa: z.coerce.number().optional()
}).refine(data => Boolean(data.stationId || data.station_id), {
    message: "stationId or station_id is required"
});

export const paginationSchema = z.object({
    page: z.coerce.number().int().min(1).default(1),
    limit: z.coerce.number().int().min(1).max(200).default(50),
    station_id: z.string().optional(),
    stationId: z.string().optional(),
    cluster: z.string().optional(),
    from: z.coerce.date().optional(),
    to: z.coerce.date().optional()
});