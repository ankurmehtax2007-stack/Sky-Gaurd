// weatherGenerator.js
import { injectAnomaly } from "./anomalyInjector.js";

/*
 * SkyGuard AI - Realistic AWS Weather Simulator
 *
 * IMPORTANT:
 * This generator creates NORMAL weather.
 * Anomalies are injected separately by anomalyInjector.js.
 *
 * The generated values intentionally have temporal correlation so that
 * anomaly detection is not simply "large value = anomaly".
 */

const stationStates = new Map();

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

const gaussianNoise = (std = 1) => {
    // Box-Muller transform
    let u = 0;
    let v = 0;

    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();

    return (
        Math.sqrt(-2.0 * Math.log(u)) *
        Math.cos(2.0 * Math.PI * v) *
        std
    );
};

const getState = (station, dateObj) => {
    const stationId = station.station_id || station.stationId;

    if (!stationStates.has(stationId)) {
        stationStates.set(stationId, {
            lastTimestamp: null,

            temperatureResidual: gaussianNoise(0.15),
            humidityResidual: gaussianNoise(0.4),
            pressureResidual: gaussianNoise(0.15),

            temperature: station.baseTemperature ?? 28,
            humidity: station.baseHumidity ?? 65,
            pressure: station.basePressure ?? 1008,

            lastHour: dateObj.getHours()
        });
    }

    return stationStates.get(stationId);
};

const generateReading = (
    station,
    forcedAnomalyType = null,
    simulatedDate = new Date()
) => {
    const dateObj =
        simulatedDate instanceof Date
            ? simulatedDate
            : new Date(simulatedDate);

    const state = getState(station, dateObj);

    const hour = dateObj.getHours();

    /*
     * ---------------------------------------------------------
     * 1. DAILY WEATHER CYCLE
     * ---------------------------------------------------------
     *
     * Temperature:
     * coolest around early morning
     * warmest around afternoon
     */

    const tempAmplitude = station.tempAmplitude ?? 5.5;

    const temperatureCycle =
        Math.sin(((hour - 8) * Math.PI) / 12) * tempAmplitude;

    /*
     * Humidity generally moves opposite to temperature.
     */
    const humidityAmplitude = station.humidityAmplitude ?? 12;

    const humidityCycle =
        -Math.sin(((hour - 8) * Math.PI) / 12) * humidityAmplitude;

    /*
     * Pressure has a much slower cycle than temperature.
     */
    const pressureCycle =
        Math.sin(((hour - 3) * Math.PI) / 12) * 1.5;

    /*
     * ---------------------------------------------------------
     * 2. TEMPORAL CORRELATION
     * ---------------------------------------------------------
     *
     * Weather doesn't jump randomly every hour.
     * We therefore use an AR-like residual process.
     */

    state.temperatureResidual =
        0.82 * state.temperatureResidual +
        gaussianNoise(0.18);

    state.humidityResidual =
        0.85 * state.humidityResidual +
        gaussianNoise(0.5);

    state.pressureResidual =
        0.92 * state.pressureResidual +
        gaussianNoise(0.12);

    /*
     * ---------------------------------------------------------
     * 3. BASE WEATHER
     * ---------------------------------------------------------
     */

    const baseTemperature =
        (station.baseTemperature ?? 28) +
        temperatureCycle;

    /*
     * Humidity depends partially on temperature.
     * When temperature rises, RH generally decreases.
     */
    const temperatureHumidityEffect =
        -(temperatureCycle * 0.9);

    let humidity =
        (station.baseHumidity ?? 65) +
        humidityCycle +
        temperatureHumidityEffect +
        state.humidityResidual;

    /*
     * ---------------------------------------------------------
     * 4. TEMPERATURE
     * ---------------------------------------------------------
     */

    let temperature =
        baseTemperature +
        state.temperatureResidual +
        gaussianNoise(0.12);

    /*
     * ---------------------------------------------------------
     * 5. PRESSURE
     * ---------------------------------------------------------
     */

    let pressure =
        (station.basePressure ?? 1008) +
        pressureCycle +
        state.pressureResidual +
        gaussianNoise(0.08);

    /*
     * ---------------------------------------------------------
     * 6. OPTIONAL WEATHER REGIME
     * ---------------------------------------------------------
     *
     * These can be supplied by the station configuration.
     *
     * Example:
     *
     * station.weatherRegime = "rainy"
     */

    const regime = station.weatherRegime || "normal";

    if (regime === "rainy") {
        humidity += 8;
        pressure -= 2;
        temperature -= 1.5;
    }

    if (regime === "cloudy") {
        humidity += 5;
        temperature -= 1;
    }

    if (regime === "dry") {
        humidity -= 12;
        temperature += 1;
    }

    /*
     * ---------------------------------------------------------
     * 7. PHYSICAL BOUNDS
     * ---------------------------------------------------------
     */

    temperature = clamp(temperature, -10, 48);

    humidity = clamp(humidity, 10, 98);

    pressure = clamp(pressure, 950, 1050);

    /*
     * ---------------------------------------------------------
     * 8. ROUND SENSOR VALUES
     * ---------------------------------------------------------
     */

    const rawTemp = Number(temperature.toFixed(2));
    const rawHumidity = Number(humidity.toFixed(1));
    const rawPressure = Number(pressure.toFixed(1));

    /*
     * ---------------------------------------------------------
     * 9. CREATE AWS READING
     * ---------------------------------------------------------
     */

    const reading = {
        station_id: station.station_id || station.stationId,
        stationId: station.station_id || station.stationId,

        station_name:
            station.station_name ||
            station.stationName ||
            "AWS Node",

        city: station.city || "New Delhi",

        state:
            station.state ||
            "Delhi",

        cluster:
            station.cluster ||
            "NCR",

        latitude:
            station.latitude ?? 28.6139,

        longitude:
            station.longitude ?? 77.2090,

        timestamp: dateObj.toISOString(),

        /*
         * Main sensor values
         */
        temperature_c: rawTemp,
        temperature: rawTemp,

        humidity_pct: rawHumidity,
        humidity: rawHumidity,

        pressure_hpa: rawPressure,
        pressure: rawPressure,

        /*
         * Useful raw metadata for feature engineering.
         * These are NOT anomaly labels.
         */
        sensor_status: "online",

        data_quality: "good"
    };

    /*
     * Store current normal state.
     */
    state.temperature = rawTemp;
    state.humidity = rawHumidity;
    state.pressure = rawPressure;

    state.lastTimestamp = dateObj.toISOString();
    state.lastHour = hour;

    /*
     * Inject anomaly AFTER normal weather generation.
     */
    return injectAnomaly(
        reading,
        forcedAnomalyType
    );
};

export { generateReading };

export default generateReading;