// anomalyInjector.js

/*
 * SkyGuard AI - Anomaly Injection Engine
 *
 * IMPORTANT:
 *
 * Ground-truth anomaly type is stored ONLY in:
 *
 *     _simulation.anomaly_type
 *
 * Your ML feature pipeline MUST exclude:
 *
 *     _simulation
 *
 * from XGBoost / Isolation Forest features.
 *
 * This metadata is only for:
 * - simulator evaluation
 * - confusion matrix
 * - precision / recall
 * - testing
 *
 * Never feed it into the model.
 */

const frozenStations = new Map();
const driftingStations = new Map();
const offsetStations = new Map();

const randomChoice = (array) =>
    array[Math.floor(Math.random() * array.length)];

const gaussianNoise = (std = 1) => {
    let u = 0;
    let v = 0;

    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();

    return (
        Math.sqrt(-2 * Math.log(u)) *
        Math.cos(2 * Math.PI * v) *
        std
    );
};

const clamp = (value, min, max) =>
    Math.min(max, Math.max(min, value));

const getStationKey = (reading) =>
    reading.station_id || reading.stationId;

/*
 * Normalize anomaly names.
 */
const normalizeAnomalyType = (type) => {
    if (type === null || type === undefined) {
        return null;
    }

    const mapping = {
        1: "temperature_spike",
        2: "humidity_spike",
        3: "pressure_jump",
        4: "freeze",
        5: "drift",
        6: "offset",
        7: "multivariate_inconsistency",
        8: "spatial_inconsistency",
        9: "missing_data",
        10: "normal",

        temp_spike: "temperature_spike",
        temperature_spike: "temperature_spike",

        humidity_spike: "humidity_spike",
        humidity_saturation: "humidity_spike",

        pressure_jump: "pressure_jump",
        pressure_drop: "pressure_jump",

        freeze: "freeze",
        frozen: "freeze",
        frozen_sensor: "freeze",

        drift: "drift",
        sensor_drift: "drift",

        offset: "offset",
        offset_step: "offset",

        multivariate_inconsistency:
            "multivariate_inconsistency",

        physics_conflict:
            "multivariate_inconsistency",

        spatial_inconsistency:
            "spatial_inconsistency",

        spatial_outlier:
            "spatial_inconsistency",

        missing_data:
            "missing_data"
    };

    return mapping[type] || type;
};

/*
 * ---------------------------------------------------------
 * NORMAL
 * ---------------------------------------------------------
 */

const injectNormal = (reading) => {
    reading._simulation = {
        anomaly_type: "normal"
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * TEMPERATURE SPIKE
 * ---------------------------------------------------------
 *
 * Do not always create absurd 50-60°C temperatures.
 *
 * Generate a mixture:
 *
 * small
 * medium
 * severe
 *
 * This makes the classifier harder and more realistic.
 */

const injectTemperatureSpike = (reading) => {
    // Sudden temperature increase (Large ΔT, high rolling z-score relative to previous readings)
    const severity = randomChoice(["medium", "large"]);
    const delta = severity === "medium" ? 10 + Math.random() * 6 : 18 + Math.random() * 8;

    reading.temperature_c = Number((reading.temperature_c + delta).toFixed(2));
    reading.temperature = reading.temperature_c;
    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "temperature_spike",
        severity,
        delta_t: Number(delta.toFixed(2))
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * HUMIDITY SATURATION
 * ---------------------------------------------------------
 *
 * Sudden/abnormal RH increase toward saturation (RH ≈ 100%, ΔRH jump,
 * breaking normal temperature/RH relationship).
 */

const injectHumiditySpike = (reading) => {
    // Force sudden/abnormal RH increase toward saturation (98.5% - 100%)
    const target = Number((98.8 + Math.random() * 1.1).toFixed(1));
    const previousRh = reading.humidity_pct;
    reading.humidity_pct = clamp(Math.max(previousRh + 35.0, target), 10, 100);
    reading.humidity = reading.humidity_pct;

    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "humidity_spike",
        delta_rh: Number((reading.humidity_pct - previousRh).toFixed(1)),
        target_rh: reading.humidity_pct,
        severity: "large"
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * PRESSURE DROP
 * ---------------------------------------------------------
 *
 * Sudden pressure decrease (Large ΔP, pressure rate jump, rolling deviation).
 */

const injectPressureJump = (reading) => {
    // Sudden pressure decrease (drop)
    const magnitude = 18 + Math.random() * 14;

    reading.pressure_hpa = Number(
        (reading.pressure_hpa - magnitude).toFixed(1)
    );

    reading.pressure = reading.pressure_hpa;
    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "pressure_jump",
        direction: "down",
        delta_p: -Number(magnitude.toFixed(1)),
        severity: "large"
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * FREEZE
 * ---------------------------------------------------------
 *
 * Freeze a single sensor for several readings.
 *
 * This creates a true temporal pattern:
 *
 * t1 = 27.31
 * t2 = 27.31
 * t3 = 27.31
 * t4 = 27.31
 * ...
 *
 * Variance ≈ 0, repeated-value count >= 4, Δsensor ≈ 0.
 */

const injectFreeze = (reading) => {
    const stationKey = getStationKey(reading);

    const sensor = randomChoice([
        "temperature",
        "humidity",
        "pressure"
    ]);

    const remaining =
        6 + Math.floor(Math.random() * 7);

    let value;

    if (sensor === "temperature") {
        value = reading.temperature_c;
    } else if (sensor === "humidity") {
        value = reading.humidity_pct;
    } else {
        value = reading.pressure_hpa;
    }

    frozenStations.set(stationKey, {
        sensor,
        value,
        remaining
    });

    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "freeze",
        sensor,
        duration: remaining
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * ACTIVE FREEZE
 * ---------------------------------------------------------
 */

const applyActiveFreeze = (reading, state) => {
    const sensor = state.sensor;

    if (sensor === "temperature") {
        reading.temperature_c = state.value;
        reading.temperature = state.value;
    }

    if (sensor === "humidity") {
        reading.humidity_pct = state.value;
        reading.humidity = state.value;
    }

    if (sensor === "pressure") {
        reading.pressure_hpa = state.value;
        reading.pressure = state.value;
    }

    reading.data_quality = "suspect";

    state.remaining--;

    if (state.remaining <= 0) {
        frozenStations.delete(
            getStationKey(reading)
        );
    }

    /*
     * Ground truth remains freeze while state is active.
     */
    reading._simulation = {
        anomaly_type: "freeze",
        sensor
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * DRIFT
 * ---------------------------------------------------------
 *
 * IMPORTANT:
 * Drift starts small and gradually increases.
 *
 * Example:
 *
 * +0.5
 * +1.0
 * +1.5
 * +2.0
 * +2.5
 *
 * This is much more useful than immediately adding +10°C.
 */

const injectDrift = (reading) => {
    const stationKey = getStationKey(reading);

    const sensor = randomChoice([
        "temperature",
        "humidity",
        "pressure"
    ]);

    const step =
        sensor === "temperature"
            ? 0.35 + Math.random() * 0.3
            : sensor === "humidity"
                ? 0.7 + Math.random() * 0.5
                : 0.15 + Math.random() * 0.15;

    const direction =
        Math.random() < 0.5 ? -1 : 1;

    const duration =
        8 + Math.floor(Math.random() * 8);

    const state = {
        sensor,
        step: step * direction,
        accumulated: 0,
        remaining: duration
    };

    driftingStations.set(
        stationKey,
        state
    );

    /*
     * Apply the first drift step immediately.
     */
    return applyActiveDrift(
        reading,
        state
    );
};

/*
 * ---------------------------------------------------------
 * ACTIVE DRIFT
 * ---------------------------------------------------------
 */

const applyActiveDrift = (reading, state) => {
    state.accumulated += state.step;

    if (state.sensor === "temperature") {
        reading.temperature_c +=
            state.accumulated;

        reading.temperature =
            reading.temperature_c;
    }

    if (state.sensor === "humidity") {
        reading.humidity_pct +=
            state.accumulated;

        reading.humidity_pct =
            clamp(
                reading.humidity_pct,
                5,
                100
            );

        reading.humidity =
            reading.humidity_pct;
    }

    if (state.sensor === "pressure") {
        reading.pressure_hpa +=
            state.accumulated;

        reading.pressure =
            reading.pressure_hpa;
    }

    /*
     * Round values.
     */
    reading.temperature_c = Number(
        reading.temperature_c.toFixed(2)
    );

    reading.humidity_pct = Number(
        reading.humidity_pct.toFixed(1)
    );

    reading.pressure_hpa = Number(
        reading.pressure_hpa.toFixed(1)
    );

    reading.data_quality = "suspect";

    state.remaining--;

    if (state.remaining <= 0) {
        driftingStations.delete(
            getStationKey(reading)
        );
    }

    reading._simulation = {
        anomaly_type: "drift",
        sensor: state.sensor
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * OFFSET
 * ---------------------------------------------------------
 *
 * Offset = sudden calibration shift that then stays roughly
 * constant.
 *
 * This is intentionally different from drift.
 */

const injectOffset = (reading) => {
    const stationKey = getStationKey(reading);

    const sensor = randomChoice([
        "temperature",
        "humidity",
        "pressure"
    ]);

    let offset;

    if (sensor === "temperature") {
        offset =
            randomChoice([
                4,
                7,
                10
            ]) + gaussianNoise(0.3);
    }

    if (sensor === "humidity") {
        offset =
            randomChoice([
                8,
                15,
                20
            ]) + gaussianNoise(0.5);
    }

    if (sensor === "pressure") {
        offset =
            randomChoice([
                4,
                8,
                12
            ]) + gaussianNoise(0.2);
    }

    offsetStations.set(
        stationKey,
        {
            sensor,
            offset
        }
    );

    return applyActiveOffset(
        reading,
        {
            sensor,
            offset
        }
    );
};

/*
 * ---------------------------------------------------------
 * ACTIVE OFFSET
 * ---------------------------------------------------------
 */

const applyActiveOffset = (reading, state) => {
    if (state.sensor === "temperature") {
        reading.temperature_c += state.offset;
        reading.temperature =
            reading.temperature_c;
    }

    if (state.sensor === "humidity") {
        reading.humidity_pct =
            clamp(
                reading.humidity_pct +
                state.offset,
                5,
                100
            );

        reading.humidity =
            reading.humidity_pct;
    }

    if (state.sensor === "pressure") {
        reading.pressure_hpa +=
            state.offset;

        reading.pressure =
            reading.pressure_hpa;
    }

    reading.temperature_c = Number(
        reading.temperature_c.toFixed(2)
    );

    reading.humidity_pct = Number(
        reading.humidity_pct.toFixed(1)
    );

    reading.pressure_hpa = Number(
        reading.pressure_hpa.toFixed(1)
    );

    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "offset",
        sensor: state.sensor
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * MULTIVARIATE INCONSISTENCY (PHYSICS CONFLICT)
 * ---------------------------------------------------------
 *
 * Sensors disagree physically/temporally:
 * Extreme temperature (43-47°C) combined with saturated humidity (92-96%)
 * or conflicting barometric pressure, directly violating thermodynamic laws
 * and cross-sensor physical constraints.
 */

const injectMultivariateInconsistency = (reading) => {
    // Physical thermodynamic inconsistency: Hot desert heat + saturated monsoon humidity
    const extremeTemp = Number((43.5 + Math.random() * 3.5).toFixed(2));
    const extremeHum = Number((92.0 + Math.random() * 5.0).toFixed(1));

    reading.temperature_c = extremeTemp;
    reading.temperature = reading.temperature_c;

    reading.humidity_pct = extremeHum;
    reading.humidity = reading.humidity_pct;

    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "multivariate_inconsistency",
        description: "Thermodynamic cross-sensor conflict (T/RH/P inconsistency)"
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * SPATIAL INCONSISTENCY (SPATIAL OUTLIER)
 * ---------------------------------------------------------
 *
 * One station differs significantly from nearby stations in the cluster.
 * Large spatial deviation / z-score against neighbor median.
 */

const injectSpatialInconsistency = (reading) => {
    // Large spatial deviation (+14°C to +18°C above cluster baseline)
    const delta = 14 + Math.random() * 4;

    reading.temperature_c = Number((reading.temperature_c + delta).toFixed(2));
    reading.temperature = reading.temperature_c;

    reading.data_quality = "suspect";

    reading._simulation = {
        anomaly_type: "spatial_inconsistency",
        spatial_delta: Number(delta.toFixed(2))
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * MISSING DATA
 * ---------------------------------------------------------
 *
 * Do not delete the entire record.
 *
 * Keep timestamp + station identity.
 * Set one or more sensor measurements to null.
 *
 * This allows the backend to detect missing sensor fields.
 */

const injectMissingData = (reading) => {
    const missingPattern =
        randomChoice([
            "temperature",
            "humidity",
            "pressure",
            "temperature_humidity",
            "all_sensors"
        ]);

    if (
        missingPattern === "temperature" ||
        missingPattern === "temperature_humidity" ||
        missingPattern === "all_sensors"
    ) {
        reading.temperature_c = null;
        reading.temperature = null;
    }

    if (
        missingPattern === "humidity" ||
        missingPattern === "temperature_humidity" ||
        missingPattern === "all_sensors"
    ) {
        reading.humidity_pct = null;
        reading.humidity = null;
    }

    if (
        missingPattern === "pressure" ||
        missingPattern === "all_sensors"
    ) {
        reading.pressure_hpa = null;
        reading.pressure = null;
    }

    reading.data_quality = "missing";

    reading._simulation = {
        anomaly_type: "missing_data",
        missing_pattern: missingPattern
    };

    return reading;
};

/*
 * ---------------------------------------------------------
 * ACTIVE STATE CHECK
 * ---------------------------------------------------------
 */

const applyActiveState = (reading) => {
    const stationKey = getStationKey(reading);

    const freezeState =
        frozenStations.get(stationKey);

    if (freezeState) {
        return applyActiveFreeze(
            reading,
            freezeState
        );
    }

    const driftState =
        driftingStations.get(stationKey);

    if (driftState) {
        return applyActiveDrift(
            reading,
            driftState
        );
    }

    const offsetState =
        offsetStations.get(stationKey);

    if (offsetState) {
        return applyActiveOffset(
            reading,
            offsetState
        );
    }

    return null;
};

/*
 * ---------------------------------------------------------
 * MAIN ANOMALY INJECTOR
 * ---------------------------------------------------------
 */

export const injectAnomaly = (
    reading,
    forcedAnomalyType = null
) => {
    /*
     * Existing multi-reading anomaly has priority.
     */
    const activeState =
        applyActiveState(reading);

    if (activeState) {
        return activeState;
    }

    /*
     * 10% anomaly rate by default.
     *
     * You can change this to 0.05 / 0.08 / 0.10.
     */
    const shouldInject =
        forcedAnomalyType !== null
            ? true
            : Math.random() < 0.10;

    if (!shouldInject) {
        return injectNormal(reading);
    }

    /*
     * If explicitly requested, use that type.
     */
    let anomalyType =
        normalizeAnomalyType(
            forcedAnomalyType
        );

    /*
     * Otherwise select randomly.
     */
    if (!anomalyType) {
        anomalyType = randomChoice([
            "temperature_spike",
            "humidity_spike",
            "pressure_jump",
            "freeze",
            "drift",
            "offset",
            "missing_data",
            "multivariate_inconsistency",
            "spatial_inconsistency"
        ]);
    }

    switch (anomalyType) {
        case "temperature_spike":
            return injectTemperatureSpike(reading);

        case "humidity_spike":
            return injectHumiditySpike(reading);

        case "pressure_jump":
            return injectPressureJump(reading);

        case "freeze":
            return injectFreeze(reading);

        case "drift":
            return injectDrift(reading);

        case "offset":
            return injectOffset(reading);

        case "missing_data":
            return injectMissingData(reading);

        case "multivariate_inconsistency":
            return injectMultivariateInconsistency(
                reading
            );

        case "spatial_inconsistency":
            return injectSpatialInconsistency(
                reading
            );

        case "normal":
        default:
            return injectNormal(reading);
    }
};

export default {
    injectAnomaly
};